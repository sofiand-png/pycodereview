# Coverage Report — Sensor Voting Reference Example
## 1. Tools
- **Test runner**: pytest
- **Coverage tool**: coverage.py (branch coverage enabled)
- **Command**:
```bash
coverage run --branch -m pytest
coverage xml
coverage html
```
Config: `.coveragerc` excludes non-critical harness modules:
```
*/app/tcp_sensor_server.py
*/app/tcp_controller_client.py
*/logging_utils/*
*/sensors/simulation.py
```
## 2. Test Suite Breakdown
### Unit tests
- tests/unit/test_voting.py
- tests/unit/test_envelope.py
- tests/unit/test_controller.py
- tests/unit/test_config_loader.py
- tests/unit/test_markers.py
- tests/unit/test_json_protocol_validation.py
### MC/DC-style tests (logical decisions)
- tests/mcdc/test_voting_mcdc.py
- tests/mcdc/test_envelope_mcdc.py
- tests/mcdc/test_controller_mcdc.py
### Integration tests
- tests/integration/test_single_step_integration.py
## 3. Coverage Metrics (core logic only)
**Statement coverage (core modules): ~100%**
`safety_logic.*`, `config.*`, `actuator.interface`, `crss_phase.markers`,
`io.json_protocol`, `app.main_loop`, `crss_modes.modes`
**Branch coverage (core modules): ~95–98%**
All key decisions in:
- `compute_voted_value`
- `apply_safety_envelope`
- `SafetyController.step`
are exercised by MC/DC-style tests.
For detailed line-by-line coverage, see `htmlcov/index.html`.
## 4. MC/DC Justification (summary)
### 4.1 compute_voted_value (voting)
Decisions covered:
- **D1**: `len(values) != 3`
- **D2**: any plausible pair exists
- **D3**: all three pairs plausible (NORMAL) vs only one pair (DEGRADED)
### 4.2 apply_safety_envelope (envelope)
Decisions covered:
- **D1**: `voted_value < min_safe` → clamp to min
- **D2**: `voted_value > max_safe` → clamp to max
- **D3**: `delta > max_delta` → positive rate limit
- **D4**: `delta < -max_delta` → negative rate limit
- **D5**: otherwise → use clamped value unchanged
### 4.3 SafetyController.step (controller)
Decisions covered:
- **D1**: voting returns FAILSAFE → FAILSAFE command
- **D2**: voting returns DEGRADED → DEGRADED command
- **D3**: voting returns NORMAL → NORMAL command
---
# Fault Model

The following faults are modelled at the sensor/input level:

1. **Single-sensor high fault**
   - One sensor is driven significantly above the plausible range
     (e.g. base + 2.5) while others remain near nominal.
2. **Single-sensor low fault**
   - One sensor is driven significantly below plausible range (e.g. base - 2.5).
3. **Severe disagreement**
   - All three sensors differ strongly (e.g. base - 2.0, base, base + 2.0),
     so no plausible pair exists.
4. **Inconsistent metadata**
   - Per-sensor status vs value range mismatches:
     - status `OK` but value out of safety range
     - status `ERROR` but value inside safety range
   - Aggregated `source_status` vs sensor_statuses mismatches:
     - `source_status = OK` but some sensors not `OK`
     - `source_status = ERROR` but all sensors `OK`
5. **Frozen sensors**
   - All three sensors stop changing and keep returning the same triplet.
6. **Stuck-at-safe with slow drift**
   - Sensors remain near a mid-range safe value and only drift very slowly
     within the safe band over time.

Faults are injected via:

- `sensors.simulation.SimulatedSensors` (modes: normal, high_fault, low_fault,
  severe_disagreement, frozen, stuck_drift)
- `_derive_sensor_statuses` in `app.tcp_sensor_server`
- random status flipping (low probability) to simulate diagnostic metadata bugs.
